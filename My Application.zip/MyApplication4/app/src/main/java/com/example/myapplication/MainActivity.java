package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    private EditText editTextNota1, editTextNota2, editTextNota3, editTextNota4;
    private Button calculateButton, limpiarButton;
    private TextView textViewResultado, textViewEstudiantesPerdieron;
    private CheckBox checkBoxPerdieron;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextNota1 = findViewById(R.id.editTextNota1);
        editTextNota2 = findViewById(R.id.editTextNota2);
        editTextNota3 = findViewById(R.id.editTextNota3);
        editTextNota4 = findViewById(R.id.editTextNota4);
        calculateButton = findViewById(R.id.calculateButton);
        limpiarButton = findViewById(R.id.limpiarButton);
        textViewResultado = findViewById(R.id.textViewResultado);
        textViewEstudiantesPerdieron = findViewById(R.id.textViewEstudiantesPerdieron);
        checkBoxPerdieron = findViewById(R.id.checkBoxPerdieron);

        calculateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calcularNota();
            }
        });

        limpiarButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                limpiarNotas();
            }
        });
    }

    private void calcularNota() {
        double nota1 = Double.parseDouble(editTextNota1.getText().toString());
        double nota2 = Double.parseDouble(editTextNota2.getText().toString());
        double nota3 = Double.parseDouble(editTextNota3.getText().toString());
        double nota4 = Double.parseDouble(editTextNota4.getText().toString());

        // Validar que las notas estén en el rango de 0 a 5
        if (nota1 < 0 || nota1 > 5 || nota2 < 0 || nota2 > 5 || nota3 < 0 || nota3 > 5 || nota4 < 0 || nota4 > 5) {
            textViewResultado.setText("Las notas deben estar entre 0 y 5.");
            return;
        }

        // Calcular la nota definitiva
        double notaDefinitiva = (nota1 * 0.2) + (nota2 * 0.3) + (nota3 * 0.15) + (nota4 * 0.35);

        // Mostrar la nota definitiva

        //redondear resultado
        DecimalFormat df = new DecimalFormat("#.##");
        notaDefinitiva = Double.valueOf(df.format(notaDefinitiva));

       // textViewResultado.setText("Nota Definitiva: " + notaDefinitiva);

        // Mostrar las notas de estudiantes que perdieron
        if (checkBoxPerdieron.isChecked() && notaDefinitiva < 3.0) {
            String notasAnteriores = textViewEstudiantesPerdieron.getText().toString();
            if (!notasAnteriores.isEmpty()) {
                notasAnteriores += "\n"; // Agregar una nueva línea si ya hay notas anteriores
            }
            textViewEstudiantesPerdieron.setText(notasAnteriores + notaDefinitiva);
        }
    }

    private void limpiarNotas() {
        // Limpia el TextView de estudiantes que perdieron
        textViewEstudiantesPerdieron.setText("");

        // Reinicia la actividad actual (la aplicación)
        Intent intent = getIntent();
        finish();
        startActivity(intent);
    }
}

